# EE2000 Signal Processing — Mid-Term Project Submission
## Team 0008: Non-Invasive Fetal ECG Extraction & FPGA Architecture

### Submission Metadata
- **Course:** EE2000: Signal Processing (Fall 2026, C Slot)
- **Instructor:** Prof. Sumohana Channappayya
- **Submission Package:** `mtr-8.zip` (Contains canonical report and complete source code)
- **Canonical Report:** `mtr-8.pdf` (and `mtr8_corrected.pdf`, CVPR/IEEE double-column format)
- **New Contributions Highlight:** All mid-term contributions since the preliminary proposal are **clearly highlighted in blue colored text** throughout `mtr-8.pdf`.

---

### Project Summary & Key Results
- **Optimal Lead Selection:** 34-channel FMR topography derived strictly on the training partition (`sub01`–`sub07`) identifies optimal 4-lead suprapubic configuration `[27, 26, 28, 25]` (0-based) / `[28, 27, 29, 26]` (1-based).
- **Strict Disjoint Subject Split:** 70% Training (`sub01`–`sub07`, 175 records), 10% Validation (`sub08`, 25 records), 20% Held-Out Testing (`sub09`–`sub10`, 50 records).
- **Benchmark Performance (250 Records, 2,250 Runs):**
  - **Spatial PCA Beamforming (4-Ch):** 93.06% F1 on held-out test subjects; 93.00% population mean (95% Clustered CI [90.65%, 95.34%], df=9; run SE 0.55%, 95% run HW ±1.08%). FHR MAE 6.57 bpm overall (3.29 bpm on normal rhythm; 0.48 bpm on Subject 1 baseline).
  - **Deep 1D Convolutional U-Net (4-Ch):** 97.48% F1 on held-out test subjects; 90.76% population mean across all 10 subjects.
- **Fixed-Point Hardware Validation [L2]:** Bit-true Q1.15 fixed-point software model verifies +74.52 dB SQNR for Spatial PCA across 5,000 golden test vectors.
- **FPGA Resource & Timing Sizing [L4 Target]:** Single DSP48E1 slice time-multiplexed schedule executes in 148 clock cycles (1.48 µs at 100 MHz on Spartan-7 XC7S50, giving an estimated 2,702x real-time margin against 4,000 µs deadline).
- **Audit Verification:** 15/15 checks passing in `tools/audit_mtr8.py` (see `audit_after.txt`).

---

### Quick Start & Single-Command Reproducibility

To reproduce all numerical metrics, consistency checks, and recompile the report PDF from scratch:

```bash
# 1. Install dependencies
pip install -r code/requirements.txt

# 2. Run automated consistency and audit checks (verifies 100% agreement across all 15 checks)
python tools/audit_mtr8.py

# 3. Regenerate LaTeX empirical macro numbers
python tools/make_numbers_tex.py

# 4. Rebuild full report and compile PDF
python report/mid_term/build_full_report.py
```
